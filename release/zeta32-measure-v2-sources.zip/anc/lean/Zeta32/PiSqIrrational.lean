/-
Copyright (c) 2022 Bhavik Mehta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Bhavik Mehta
-/
-- adapted from Mathlib/Analysis/Real/Pi/Irrational.lean
-- strengthened from `Irrational π` to `Irrational (π ^ 2)`.
module

public import Mathlib.Analysis.SpecialFunctions.Integrals.Basic
public import Mathlib.Topology.Algebra.Order.Floor
public import Mathlib.NumberTheory.Real.Irrational

/-!
# `Real.pi ^ 2` is irrational

The main result of this file is `Zeta32.irrational_pi_sq`.

The proof is Cartwright's integral argument, exactly as in Mathlib's
`Mathlib/Analysis/Real/Pi/Irrational.lean` (the definitions `I`, `sinPoly`, `cosPoly` and the
recursion / evaluation lemmas are copied verbatim, since they are private there). The only new
observation is Niven's: `sinPoly n` is an even polynomial, i.e.
`sinPoly n (θ) = sinPolyY n (θ ^ 2)` for an integer polynomial `sinPolyY n` of degree `≤ n`.
Hence, at `θ = π / 2` (where `cos θ = 0`, `sin θ = 1`),
`I n θ * θ * (θ ^ 2) ^ n = n ! * sinPolyY n (θ ^ 2)`.
If `θ ^ 2 = a / b` with `a, b > 0`, then `b ^ n * sinPolyY n (a / b)` is an integer, equal to
`a ^ n / n ! * θ * I n θ ∈ (0, 2 θ a ^ n / n !]`, which tends to `0`: contradiction.
So `π ^ 2 / 4` is irrational, hence so is `π ^ 2`.
-/

public section

noncomputable section

open intervalIntegral MeasureTheory.MeasureSpace Set Polynomial Real
open scoped Nat

namespace Zeta32.PiSq

/-- The sequence of integrals used for Cartwright's proof of irrationality of `π`. -/
private def I (n : ℕ) (θ : ℝ) : ℝ := ∫ x in (-1)..1, (1 - x ^ 2) ^ n * cos (x * θ)

variable {n : ℕ} {θ : ℝ}

private lemma I_zero : I 0 θ * θ = 2 * sin θ := by
  rw [mul_comm, I]
  simp [mul_integral_comp_mul_right, two_mul]

private lemma recursion' (n : ℕ) :
    I (n + 1) θ * θ ^ 2 = - (2 * 2 * ((n + 1) * (0 ^ n * cos θ))) +
      2 * (n + 1) * (2 * n + 1) * I n θ - 4 * (n + 1) * n * I (n - 1) θ := by
  rw [I]
  let f (x : ℝ) : ℝ := 1 - x ^ 2
  let u₁ (x : ℝ) : ℝ := f x ^ (n + 1)
  let u₁' (x : ℝ) : ℝ := - (2 * (n + 1) * x * f x ^ n)
  let v₁ (x : ℝ) : ℝ := sin (x * θ)
  let v₁' (x : ℝ) : ℝ := cos (x * θ) * θ
  let u₂ (x : ℝ) : ℝ := x * (f x) ^ n
  let u₂' (x : ℝ) : ℝ := (f x) ^ n - 2 * n * x ^ 2 * (f x) ^ (n - 1)
  let v₂ (x : ℝ) : ℝ := cos (x * θ)
  let v₂' (x : ℝ) : ℝ := -sin (x * θ) * θ
  have hfd : Continuous f := by fun_prop
  have hu₁d : Continuous u₁' := by fun_prop
  have hv₁d : Continuous v₁' := by fun_prop
  have hu₂d : Continuous u₂' := by fun_prop
  have hv₂d : Continuous v₂' := by fun_prop
  have hu₁_eval_one : u₁ 1 = 0 := by simp only [u₁, f]; simp
  have hu₁_eval_neg_one : u₁ (-1) = 0 := by simp only [u₁, f]; simp
  have t : u₂ 1 * v₂ 1 - u₂ (-1) * v₂ (-1) = 2 * (0 ^ n * cos θ) := by simp [u₂, v₂, f, ← two_mul]
  have hf (x) : HasDerivAt f (- 2 * x) x := by
    convert! (hasDerivAt_pow 2 x).const_sub 1 using 1
    simp
  have hu₁ (x) : HasDerivAt u₁ (u₁' x) x := by
    convert! (hf x).pow _ using 1
    simp only [Nat.add_succ_sub_one, u₁', Nat.cast_add_one]
    ring
  have hv₁ (x) : HasDerivAt v₁ (v₁' x) x := (hasDerivAt_mul_const θ).sin
  have hu₂ (x) : HasDerivAt u₂ (u₂' x) x := by
    convert! (hasDerivAt_id' x).fun_mul ((hf x).fun_pow _) using 1
    simp only [u₂']
    ring
  have hv₂ (x) : HasDerivAt v₂ (v₂' x) x := (hasDerivAt_mul_const θ).cos
  convert_to (∫ (x : ℝ) in (-1)..1, u₁ x * v₁' x) * θ = _ using 1
  · simp_rw [u₁, v₁', f, ← intervalIntegral.integral_mul_const, sq θ, mul_assoc]
  rw [integral_mul_deriv_eq_deriv_mul (fun x _ => hu₁ x) (fun x _ => hv₁ x)
    (hu₁d.intervalIntegrable _ _) (hv₁d.intervalIntegrable _ _), hu₁_eval_one, hu₁_eval_neg_one,
    zero_mul, zero_mul, sub_zero, zero_sub, ← integral_neg, ← integral_mul_const]
  convert_to ((-2 : ℝ) * (n + 1)) * ∫ (x : ℝ) in (-1)..1, (u₂ x * v₂' x) = _ using 1
  · rw [← integral_const_mul]
    congr 1 with x
    dsimp [u₁', v₁, u₂, v₂']
    ring
  rw [integral_mul_deriv_eq_deriv_mul (fun x _ => hu₂ x) (fun x _ => hv₂ x)
    (hu₂d.intervalIntegrable _ _) (hv₂d.intervalIntegrable _ _),
    mul_sub, t, neg_mul, neg_mul, neg_mul, sub_neg_eq_add]
  have (x : _) : u₂' x = (2 * n + 1) * f x ^ n - 2 * n * f x ^ (n - 1) := by
    cases n with
    | zero => simp [u₂']
    | succ n => ring!
  simp_rw [this, sub_mul, mul_assoc _ _ (v₂ _)]
  have : Continuous v₂ := by fun_prop
  rw [mul_mul_mul_comm, integral_sub, mul_sub, add_sub_assoc]
  · congr 1
    simp_rw [integral_const_mul]
    ring!
  all_goals exact Continuous.intervalIntegrable (by fun_prop) _ _

private lemma recursion (n : ℕ) :
    I (n + 2) θ * θ ^ 2 =
      2 * (n + 2) * (2 * n + 3) * I (n + 1) θ - 4 * (n + 2) * (n + 1) * I n θ := by
  rw [recursion' (n + 1)]
  push_cast
  ring

private lemma I_one : I 1 θ * θ ^ 3 = 4 * sin θ - 4 * θ * cos θ := by
  rw [_root_.pow_succ, ← mul_assoc, recursion' 0, sub_mul, add_mul, mul_assoc _ (I 0 θ), I_zero]
  ring

private def sinPoly : ℕ → ℤ[X]
  | 0 => C 2
  | 1 => C 4
  | n + 2 => ((2 : ℤ) * (2 * n + 3)) • sinPoly (n + 1) + monomial 2 (-4) * sinPoly n

private def cosPoly : ℕ → ℤ[X]
  | 0 => 0
  | 1 => monomial 1 (-4)
  | n + 2 => ((2 : ℤ) * (2 * n + 3)) • cosPoly (n + 1) + monomial 2 (-4) * cosPoly n

private lemma sinPoly_add_cosPoly_eval (θ : ℝ) :
    ∀ n : ℕ,
      I n θ * θ ^ (2 * n + 1) = n ! * ((sinPoly n).eval₂ (Int.castRingHom _) θ * sin θ +
        (cosPoly n).eval₂ (Int.castRingHom _) θ * cos θ)
  | 0 => by simp [sinPoly, cosPoly, I_zero]
  | 1 => by simp [I_one, sinPoly, cosPoly, sub_eq_add_neg]
  | n + 2 => by
      calc I (n + 2) θ * θ ^ (2 * (n + 2) + 1) = I (n + 2) θ * θ ^ 2 * θ ^ (2 * n + 3) := by ring
        _ = 2 * (n + 2) * (2 * n + 3) * (I (n + 1) θ * θ ^ (2 * (n + 1) + 1)) -
            4 * (n + 2) * (n + 1) * θ ^ 2 * (I n θ * θ ^ (2 * n + 1)) := by rw [recursion]; ring
        _ = _ := by simp [sinPoly_add_cosPoly_eval, sinPoly, cosPoly, Nat.factorial_succ]; ring

/-! ### New (Niven): `sinPoly n` is a polynomial in `X ^ 2`. -/

/-- `sinPoly n = sinPolyY n ∘ X ^ 2`: same recursion with `monomial 2` replaced by
`monomial 1`. -/
private def sinPolyY : ℕ → ℤ[X]
  | 0 => C 2
  | 1 => C 4
  | n + 2 => ((2 : ℤ) * (2 * n + 3)) • sinPolyY (n + 1) + monomial 1 (-4) * sinPolyY n

private lemma sinPoly_eval₂_eq (θ : ℝ) :
    ∀ n : ℕ, (sinPoly n).eval₂ (Int.castRingHom ℝ) θ =
      (sinPolyY n).eval₂ (Int.castRingHom ℝ) (θ ^ 2)
  | 0 => by simp [sinPoly, sinPolyY]
  | 1 => by simp [sinPoly, sinPolyY]
  | n + 2 => by
      simp only [sinPoly, sinPolyY, eval₂_add, eval₂_smul, eval₂_mul, eval₂_monomial,
        sinPoly_eval₂_eq θ n, sinPoly_eval₂_eq θ (n + 1)]
      ring

private lemma sinPolyY_natDegree_le : ∀ n : ℕ, (sinPolyY n).natDegree ≤ n
  | 0
  | 1 => by simp [sinPolyY]
  | n + 2 => by
    rw [sinPolyY]
    refine natDegree_add_le_of_degree_le ((natDegree_smul_le _ _).trans ?_) ?_
    · exact (sinPolyY_natDegree_le (n + 1)).trans (by simp)
    refine natDegree_mul_le.trans ?_
    have h1 : (monomial 1 (-4 : ℤ)).natDegree ≤ 1 := natDegree_monomial_le _
    have h2 := sinPolyY_natDegree_le n
    omega

private lemma is_integer {p : ℤ[X]} (a b : ℤ) {k : ℕ} (hp : p.natDegree ≤ k) :
    ∃ z : ℤ, p.eval₂ (Int.castRingHom ℝ) (a / b) * b ^ k = z := by
  rcases eq_or_ne b 0 with rfl | hb
  · rcases k.eq_zero_or_pos with rfl | hk
    · exact ⟨p.coeff 0, by simp⟩
    exact ⟨0, by simp [hk.ne']⟩
  refine ⟨∑ i ∈ p.support, p.coeff i * a ^ i * b ^ (k - i), ?_⟩
  conv => lhs; rw [← sum_monomial_eq p]
  rw [eval₂_sum, sum, Finset.sum_mul, Int.cast_sum]
  simp only [eval₂_monomial, eq_intCast, div_pow, Int.cast_mul, Int.cast_pow]
  refine Finset.sum_congr rfl (fun i hi => ?_)
  have ik := (le_natDegree_of_mem_supp i hi).trans hp
  rw [mul_assoc, div_mul_comm, ← Int.cast_pow, ← Int.cast_pow, ← Int.cast_pow,
    ← pow_sub_mul_pow b ik, ← Int.cast_div_charZero, Int.mul_ediv_cancel _ (pow_ne_zero _ hb),
    ← mul_assoc, mul_right_comm, ← Int.cast_pow]
  exact dvd_mul_left _ _

open Filter

private lemma I_pos : 0 < I n (π / 2) := by
  refine integral_pos (by simp) (by fun_prop) ?_ ⟨0, by simp⟩
  refine fun x hx => mul_nonneg (pow_nonneg ?_ _) ?_
  · rw [sub_nonneg, sq_le_one_iff_abs_le_one, abs_le]
    exact ⟨hx.1.le, hx.2⟩
  refine cos_nonneg_of_neg_pi_div_two_le_of_le ?_ ?_ <;>
  nlinarith [hx.1, hx.2, pi_pos]

private lemma I_le (n : ℕ) : I n (π / 2) ≤ 2 := by
  rw [← norm_of_nonneg I_pos.le]
  refine (norm_integral_le_of_norm_le_const ?_).trans (show (1 : ℝ) * _ ≤ _ by norm_num)
  intro x hx
  simp only [uIoc_of_le, neg_le_self_iff, zero_le_one, mem_Ioc] at hx
  rw [norm_eq_abs, abs_mul, abs_pow]
  have : |1 - x ^ 2| ≤ 1 := by
    rw [abs_le]
    constructor <;> nlinarith
  bound [abs_cos_le_one]

private lemma not_irrational_exists_rep {x : ℝ} :
    ¬Irrational x → ∃ (a : ℤ) (b : ℕ), 0 < b ∧ x = a / b := by
  rw [Irrational, not_not, mem_range]
  rintro ⟨q, rfl⟩
  exact ⟨q.num, q.den, q.pos, by exact_mod_cast (Rat.num_div_den _).symm⟩

end Zeta32.PiSq

namespace Zeta32

open Zeta32.PiSq Filter

/-- `π ^ 2` is irrational (Niven's variant of Cartwright's argument). -/
theorem irrational_pi_sq : Irrational (π ^ 2) := by
  apply Irrational.of_div_natCast 4
  have h4 : (π ^ 2 / ((4 : ℕ) : ℝ)) = (π / 2) ^ 2 := by push_cast; ring
  rw [h4]
  by_contra h'
  obtain ⟨a, b, hb, h⟩ := not_irrational_exists_rep h'
  have hθ : 0 < π / 2 := pi_div_two_pos
  have hbR : (0 : ℝ) < b := by exact_mod_cast hb
  have ha : (0 : ℝ) < a := by
    have : 0 < (a : ℝ) / b := h ▸ pow_pos hθ 2
    rwa [lt_div_iff₀ hbR, zero_mul] at this
  have k (n : ℕ) : 0 < (a : ℝ) ^ n / n ! * (π / 2) := by positivity
  have j : ∀ᶠ n : ℕ in atTop, (a : ℝ) ^ n / n ! * (π / 2) * I n (π / 2) < 1 := by
    have hlim := ((FloorSemiring.tendsto_pow_div_factorial_atTop (a : ℝ)).const_mul
      (2 * (π / 2))).eventually_lt_const (show (2 * (π / 2)) * 0 < 1 by simp)
    filter_upwards [hlim] with n hn
    calc (a : ℝ) ^ n / n ! * (π / 2) * I n (π / 2) ≤ (a : ℝ) ^ n / n ! * (π / 2) * 2 :=
          mul_le_mul_of_nonneg_left (I_le _) (k n).le
      _ = 2 * (π / 2) * ((a : ℝ) ^ n / n !) := by ring
      _ < 1 := hn
  obtain ⟨n, hn⟩ := j.exists
  have hn' : 0 < (a : ℝ) ^ n / n ! * (π / 2) * I n (π / 2) := mul_pos (k _) I_pos
  obtain ⟨z, hz⟩ : ∃ z : ℤ,
      (sinPolyY n).eval₂ (Int.castRingHom ℝ) (a / b) * ((b : ℤ) : ℝ) ^ n = z :=
    is_integer a b (sinPolyY_natDegree_le n)
  have e := sinPoly_add_cosPoly_eval (π / 2) n
  rw [cos_pi_div_two, sin_pi_div_two, mul_zero, mul_one, add_zero, sinPoly_eval₂_eq, h] at e
  have hpow : (π / 2) ^ (2 * n + 1) = (π / 2) * ((a : ℝ) / b) ^ n := by
    rw [pow_succ, pow_mul, h, mul_comm]
  rw [hpow] at e
  have key : (a : ℝ) ^ n / n ! * (π / 2) * I n (π / 2) =
      (sinPolyY n).eval₂ (Int.castRingHom ℝ) (a / b) * ((b : ℤ) : ℝ) ^ n := by
    have hfac : (0 : ℝ) < n ! := by exact_mod_cast Nat.factorial_pos n
    have hbn : (0 : ℝ) < (b : ℝ) ^ n := pow_pos hbR n
    rw [div_pow] at e
    push_cast
    field_simp at e ⊢
    linear_combination e
  have : (0 : ℝ) < z ∧ (z : ℝ) < 1 := by
    rw [← hz, ← key]
    exact ⟨hn', hn⟩
  norm_cast at this
  lia

end Zeta32
